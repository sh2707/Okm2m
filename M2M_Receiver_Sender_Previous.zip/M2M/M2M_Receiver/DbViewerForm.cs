using System.Text;
using System.Text.RegularExpressions;

namespace M2M_Receiver;

/// <summary>Search window for the DB\*.udb files: by date and/or text, CSV export, and a download symbol per record (Text / XML / CSV).</summary>
public sealed class DbViewerForm : Form
{
    private const int MaxRows = 5000;

    private readonly string dbDir;
    private readonly DateTimePicker dtp = new() { Format = DateTimePickerFormat.Short, Width = 110 };
    private readonly CheckBox chkAllDates = new() { Text = "All dates", AutoSize = true, Margin = new Padding(8, 6, 8, 0) };
    private readonly TextBox txtFilter = new() { Width = 260 };
    private readonly Button btnSearch = new() { Text = "Search", Width = 80 };
    private readonly Button btnExport = new() { Text = "Export CSV...", Width = 100 };
    private readonly Label lblCount = new() { AutoSize = true, Margin = new Padding(12, 7, 0, 0), Text = "" };
    private readonly ListView lv = new() { Dock = DockStyle.Fill, View = View.Details, FullRowSelect = true, GridLines = true };
    private readonly TextBox txtDetail = new()
    {
        Dock = DockStyle.Bottom,
        Height = 150,
        Multiline = true,
        ReadOnly = true,
        ScrollBars = ScrollBars.Both,
        WordWrap = false,
        Font = new Font("Consolas", 10)
    };

    private readonly TabControl tabs = new() { Dock = DockStyle.Top, Height = 84 };
    private readonly RadioButton rbText = new() { Text = "Text file (.txt)", AutoSize = true, Checked = true, Margin = new Padding(0, 4, 18, 0) };
    private readonly RadioButton rbXml = new() { Text = "XML file (.xml)", AutoSize = true, Margin = new Padding(0, 4, 18, 0) };
    private readonly RadioButton rbCsv = new() { Text = "CSV file (.csv)", AutoSize = true, Margin = new Padding(0, 4, 18, 0) };

    private static readonly Font SymbolFont = new("Segoe UI Symbol", 11, FontStyle.Bold);

    private List<DbRecord> shown = new();

    public DbViewerForm(string dbDirectory)
    {
        dbDir = dbDirectory;
        Text = "DB Search";
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(980, 600);
        MinimumSize = new Size(700, 400);

        lv.Columns.Add("Download", 70);
        lv.Columns.Add("Date / time", 160);
        lv.Columns.Add("Content", 720);

        var top = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 40, Padding = new Padding(6, 6, 6, 0) };
        top.Controls.Add(new Label { Text = "Date", AutoSize = true, Margin = new Padding(0, 7, 4, 0) });
        top.Controls.Add(dtp);
        top.Controls.Add(chkAllDates);
        top.Controls.Add(new Label { Text = "Text", AutoSize = true, Margin = new Padding(8, 7, 4, 0) });
        top.Controls.Add(txtFilter);
        top.Controls.Add(btnSearch);
        top.Controls.Add(btnExport);
        top.Controls.Add(lblCount);

        // tab 1: Search (the old controls)   tab 2: Download file (choose the format of the download symbol)
        top.Dock = DockStyle.Fill;
        var tabSearch = new TabPage("Search");
        tabSearch.Controls.Add(top);

        var tabDownload = new TabPage("Download file");
        var formats = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 28, Padding = new Padding(8, 2, 0, 0) };
        formats.Controls.Add(new Label { Text = "Format", AutoSize = true, Margin = new Padding(0, 6, 10, 0) });
        formats.Controls.Add(rbText);
        formats.Controls.Add(rbXml);
        formats.Controls.Add(rbCsv);
        var hint = new Label
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(8, 2, 0, 0),
            Text = "Click the download symbol (\u2B07) in front of a received record in the list to save that record in the selected format."
        };
        tabDownload.Controls.Add(hint);
        tabDownload.Controls.Add(formats);

        tabs.TabPages.Add(tabSearch);
        tabs.TabPages.Add(tabDownload);

        // dock order: the control added last is laid out first
        Controls.Add(lv);
        Controls.Add(txtDetail);
        Controls.Add(tabs);

        AcceptButton = btnSearch;
        chkAllDates.CheckedChanged += (_, _) => dtp.Enabled = !chkAllDates.Checked;
        btnSearch.Click += async (_, _) => await RunSearchAsync();
        btnExport.Click += (_, _) => ExportCsv();
        lv.SelectedIndexChanged += (_, _) => ShowDetail();
        lv.MouseClick += Lv_MouseClick;
        Shown += async (_, _) => await RunSearchAsync();
    }

    private async Task RunSearchAsync()
    {
        btnSearch.Enabled = false;
        lblCount.Text = "Searching ...";
        try
        {
            string filter = txtFilter.Text.Trim();
            DateTime? day = chkAllDates.Checked ? null : dtp.Value.Date;
            List<DbRecord> found = await Task.Run(() => DbReader.Search(dbDir, day, filter));

            shown = found.Count > MaxRows ? found.GetRange(0, MaxRows) : found;

            lv.BeginUpdate();
            lv.Items.Clear();
            foreach (DbRecord r in shown)
            {
                var item = new ListViewItem(new[] { "\u2B07", r.Time.ToString("yyyy-MM-dd HH:mm:ss.fff"), Flatten(r.Content) });
                item.UseItemStyleForSubItems = false;
                item.SubItems[0].Font = SymbolFont;
                item.SubItems[0].ForeColor = Color.RoyalBlue;
                lv.Items.Add(item);
            }
            lv.EndUpdate();
            txtDetail.Text = "";

            lblCount.Text = found.Count > MaxRows
                ? $"{found.Count} records found - first {MaxRows} shown (narrow the search, or Export CSV for all)"
                : $"{found.Count} record(s) found";
            lastFound = found;
        }
        catch (Exception ex)
        {
            lblCount.Text = "Search failed: " + ex.Message;
        }
        finally
        {
            btnSearch.Enabled = true;
        }
    }

    private List<DbRecord> lastFound = new();

    private static string Flatten(string s) => s.Replace("\r", "").Replace("\n", " | ");

    private void ShowDetail()
    {
        if (lv.SelectedIndices.Count == 0) { txtDetail.Text = ""; return; }
        int i = lv.SelectedIndices[0];
        if (i < 0 || i >= shown.Count) return;
        txtDetail.Text = shown[i].Content.Replace("\r\n", "\n").Replace("\n", "\r\n");
    }

    // ---- download symbol: saves ONE received record as .txt / .xml / .csv (format chosen in the "Download file" tab) ----

    private void Lv_MouseClick(object? sender, MouseEventArgs e)
    {
        ListViewHitTestInfo hit = lv.HitTest(e.Location);
        if (hit.Item == null || hit.SubItem == null) return;
        if (hit.Item.SubItems.IndexOf(hit.SubItem) != 0) return;   // only the download symbol column

        int i = hit.Item.Index;
        if (i >= 0 && i < shown.Count) DownloadRecord(shown[i]);
    }

    private void DownloadRecord(DbRecord r)
    {
        string ext = rbXml.Checked ? ".xml" : rbCsv.Checked ? ".csv" : ".txt";
        string kind = rbXml.Checked ? "XML file" : rbCsv.Checked ? "CSV file" : "Text file";

        using var dlg = new SaveFileDialog
        {
            Title = "Download received data",
            Filter = $"{kind} (*{ext})|*{ext}",
            DefaultExt = ext.TrimStart('.'),
            AddExtension = true,
            FileName = "M2M_" + r.Time.ToString("yyyyMMdd_HHmmss_fff") + ext
        };
        if (dlg.ShowDialog(this) != DialogResult.OK) return;

        try
        {
            string time = r.Time.ToString("yyyy-MM-dd HH:mm:ss.fff");
            string text;
            bool bom = false;

            if (rbXml.Checked)
            {
                // characters that are not allowed in XML are removed; "]]>" is split so the CDATA stays valid
                string safe = Regex.Replace(r.Content, "[^\u0009\u000A\u000D\u0020-\uD7FF\uE000-\uFFFD]", "")
                                   .Replace("]]>", "]]]]><![CDATA[>");
                text = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n<M2M_Data>\r\n"
                     + $"  <Message time=\"{time}\"><![CDATA[{safe}]]></Message>\r\n</M2M_Data>\r\n";
            }
            else if (rbCsv.Checked)
            {
                text = "Time,Content\r\n" + time + ",\"" + r.Content.Replace("\"", "\"\"") + "\"\r\n";
                bom = true;   // so Excel shows the characters correctly
            }
            else
            {
                text = r.Content;   // exactly what was received
            }

            File.WriteAllText(dlg.FileName, text, new UTF8Encoding(bom));
            MessageBox.Show(this, "Saved:\r\n" + dlg.FileName, "Download", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Download failed: " + ex.Message, "Download", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void ExportCsv()
    {
        if (lastFound.Count == 0)
        {
            MessageBox.Show(this, "Nothing to export. Search first.", "DB Search", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        using var dlg = new SaveFileDialog
        {
            Title = "Export search result",
            Filter = "CSV file (*.csv)|*.csv",
            FileName = "M2M_DB_Export_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".csv"
        };
        if (dlg.ShowDialog(this) != DialogResult.OK) return;

        try
        {
            var sb = new StringBuilder();
            sb.Append("Time,Content\r\n");
            foreach (DbRecord r in lastFound)
                sb.Append(r.Time.ToString("yyyy-MM-dd HH:mm:ss.fff")).Append(",\"").Append(r.Content.Replace("\"", "\"\"")).Append("\"\r\n");
            File.WriteAllText(dlg.FileName, sb.ToString(), new UTF8Encoding(true));
            MessageBox.Show(this, $"{lastFound.Count} record(s) exported.", "DB Search", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Export failed: " + ex.Message, "DB Search", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
