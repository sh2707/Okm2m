using System.Text;

namespace M2M.Shared;

public enum FramingMode
{
    /// <summary>No framing: whatever arrives together is one message (same as the old apps).</summary>
    None = 0,
    /// <summary>One message per line, ends with \n (or \r\n).</summary>
    Line = 1,
    /// <summary>STX (0x02) ... ETX (0x03).</summary>
    StxEtx = 2,
    /// <summary>2-byte big-endian length, then that many bytes.</summary>
    LengthPrefix = 3,
    /// <summary>Every message is exactly FixedLength bytes (padded with 0x00).</summary>
    Fixed = 4
}

public enum ChecksumMode
{
    None = 0,
    Xor = 1,
    Sum8 = 2,
    Crc16 = 3
}

public static class Checksums
{
    /// <summary>Number of ASCII hex characters the checksum takes inside a frame.</summary>
    public static int HexLength(ChecksumMode m)
    {
        switch (m)
        {
            case ChecksumMode.Xor: return 2;
            case ChecksumMode.Sum8: return 2;
            case ChecksumMode.Crc16: return 4;
            default: return 0;
        }
    }

    public static string Hex(ChecksumMode m, byte[] data)
    {
        switch (m)
        {
            case ChecksumMode.Xor:
            {
                int x = 0;
                foreach (byte b in data) x ^= b;
                return x.ToString("X2");
            }
            case ChecksumMode.Sum8:
            {
                int s = 0;
                foreach (byte b in data) s = (s + b) & 0xFF;
                return s.ToString("X2");
            }
            case ChecksumMode.Crc16:
                return Crc16(data).ToString("X4");
            default:
                return "";
        }
    }

    /// <summary>CRC-16/MODBUS (poly 0xA001, init 0xFFFF).</summary>
    public static int Crc16(byte[] data)
    {
        int crc = 0xFFFF;
        foreach (byte b in data)
        {
            crc ^= b;
            for (int i = 0; i < 8; i++)
                crc = (crc & 1) != 0 ? (crc >> 1) ^ 0xA001 : crc >> 1;
        }
        return crc & 0xFFFF;
    }
}

public static class FrameBuilder
{
    /// <summary>Turns a message into the bytes that go on the wire.</summary>
    public static byte[] Wrap(byte[] payload, FramingMode mode, ChecksumMode checksum, int fixedLength)
    {
        switch (mode)
        {
            case FramingMode.Line:
                return Concat(payload, new byte[] { 0x0D, 0x0A });

            case FramingMode.StxEtx:
            {
                byte[] body = WithChecksum(payload, checksum);
                return Concat(new byte[] { 0x02 }, body, new byte[] { 0x03 });
            }

            case FramingMode.LengthPrefix:
            {
                byte[] body = WithChecksum(payload, checksum);
                if (body.Length > 65535) throw new InvalidOperationException("Message is longer than 65535 bytes");
                return Concat(new byte[] { (byte)(body.Length >> 8), (byte)(body.Length & 0xFF) }, body);
            }

            case FramingMode.Fixed:
            {
                int n = Math.Max(1, fixedLength);
                if (payload.Length > n) throw new InvalidOperationException($"Message ({payload.Length} bytes) is longer than the fixed length ({n})");
                byte[] frame = new byte[n];
                Buffer.BlockCopy(payload, 0, frame, 0, payload.Length);
                return frame;
            }

            default:
                return payload;
        }
    }

    /// <summary>
    /// Takes what the assembler extracted and returns the real message.
    /// checksumOk is null when no checksum is used for this mode.
    /// </summary>
    public static byte[] Unwrap(byte[] content, FramingMode mode, ChecksumMode checksum, out bool? checksumOk)
    {
        checksumOk = null;

        if (mode == FramingMode.Fixed)
        {
            int n = content.Length;
            while (n > 0 && content[n - 1] == 0) n--;
            byte[] trimmed = new byte[n];
            Buffer.BlockCopy(content, 0, trimmed, 0, n);
            return trimmed;
        }

        if ((mode == FramingMode.StxEtx || mode == FramingMode.LengthPrefix) && checksum != ChecksumMode.None)
        {
            int len = Checksums.HexLength(checksum);
            if (content.Length < len)
            {
                checksumOk = false;
                return content;
            }
            byte[] payload = new byte[content.Length - len];
            Buffer.BlockCopy(content, 0, payload, 0, payload.Length);
            string got = Encoding.ASCII.GetString(content, content.Length - len, len);
            checksumOk = got.Equals(Checksums.Hex(checksum, payload), StringComparison.OrdinalIgnoreCase);
            return payload;
        }

        return content;
    }

    private static byte[] WithChecksum(byte[] payload, ChecksumMode checksum)
    {
        if (checksum == ChecksumMode.None) return payload;
        return Concat(payload, Encoding.ASCII.GetBytes(Checksums.Hex(checksum, payload)));
    }

    private static byte[] Concat(params byte[][] parts)
    {
        int total = 0;
        foreach (var p in parts) total += p.Length;
        byte[] result = new byte[total];
        int pos = 0;
        foreach (var p in parts)
        {
            Buffer.BlockCopy(p, 0, result, pos, p.Length);
            pos += p.Length;
        }
        return result;
    }
}

/// <summary>
/// Collects the raw bytes of ONE connection and cuts them into messages.
/// TCP is a byte stream (no built-in "messages"), so this is what decides where a message ends.
/// Everything runs on the UI thread, so there is no locking.
/// </summary>
public sealed class MessageAssembler
{
    private const int MaxBuffer = 1 << 20;   // 1 MB safety limit

    private readonly List<byte> buf = new();
    private long lastRxTick = Environment.TickCount64;

    public FramingMode Mode { get; set; } = FramingMode.None;
    public int FixedLength { get; set; } = 16;
    public int Pending => buf.Count;

    /// <summary>Adds received bytes, returns the messages that are complete now.</summary>
    public List<byte[]> Feed(byte[] data, int count, Action<string>? warn = null)
    {
        buf.AddRange(new ArraySegment<byte>(data, 0, count));
        lastRxTick = Environment.TickCount64;
        return Extract(warn);
    }

    /// <summary>
    /// Mode None only: if nothing new arrived for gapMs, everything collected so far is one message.
    /// Call this from a timer.
    /// </summary>
    public byte[]? PollGap(int gapMs)
    {
        if (Mode != FramingMode.None || buf.Count == 0) return null;
        if (Environment.TickCount64 - lastRxTick < gapMs) return null;
        return TakeAll();
    }

    /// <summary>Connection closed: returns whatever is left (None / Line modes), or warns about a half frame.</summary>
    public byte[]? Finish(Action<string>? warn = null)
    {
        if (buf.Count == 0) return null;
        if (Mode == FramingMode.None || Mode == FramingMode.Line) return TakeAll();
        warn?.Invoke($"Incomplete frame discarded ({buf.Count} bytes)");
        buf.Clear();
        return null;
    }

    private byte[] TakeAll()
    {
        byte[] all = buf.ToArray();
        buf.Clear();
        return all;
    }

    private List<byte[]> Extract(Action<string>? warn)
    {
        var frames = new List<byte[]>();

        switch (Mode)
        {
            case FramingMode.Line:
            {
                int nl;
                while ((nl = buf.IndexOf((byte)0x0A)) >= 0)
                {
                    int len = nl;
                    if (len > 0 && buf[len - 1] == 0x0D) len--;
                    frames.Add(buf.GetRange(0, len).ToArray());
                    buf.RemoveRange(0, nl + 1);
                }
                break;
            }

            case FramingMode.StxEtx:
            {
                while (true)
                {
                    int stx = buf.IndexOf((byte)0x02);
                    if (stx < 0)
                    {
                        if (buf.Count > 0)
                        {
                            warn?.Invoke($"Ignored {buf.Count} byte(s) outside STX/ETX");
                            buf.Clear();
                        }
                        break;
                    }
                    if (stx > 0)
                    {
                        warn?.Invoke($"Ignored {stx} byte(s) before STX");
                        buf.RemoveRange(0, stx);
                    }
                    int etx = buf.IndexOf((byte)0x03, 1);
                    if (etx < 0) break;   // wait for the rest
                    frames.Add(buf.GetRange(1, etx - 1).ToArray());
                    buf.RemoveRange(0, etx + 1);
                }
                break;
            }

            case FramingMode.LengthPrefix:
            {
                while (buf.Count >= 2)
                {
                    int len = (buf[0] << 8) | buf[1];
                    if (buf.Count < 2 + len) break;   // wait for the rest
                    frames.Add(buf.GetRange(2, len).ToArray());
                    buf.RemoveRange(0, 2 + len);
                }
                break;
            }

            case FramingMode.Fixed:
            {
                int n = Math.Max(1, FixedLength);
                while (buf.Count >= n)
                {
                    frames.Add(buf.GetRange(0, n).ToArray());
                    buf.RemoveRange(0, n);
                }
                break;
            }

            default:
                break;   // None: the gap timer decides
        }

        if (buf.Count > MaxBuffer)
        {
            if (Mode == FramingMode.None)
            {
                frames.Add(TakeAll());
            }
            else
            {
                warn?.Invoke("Buffer overflow - data discarded (check the Framing setting)");
                buf.Clear();
            }
        }

        return frames;
    }
}
