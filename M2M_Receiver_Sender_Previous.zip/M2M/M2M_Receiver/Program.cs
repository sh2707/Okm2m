namespace M2M_Receiver;

static class Program
{
    [STAThread]
    static void Main()
    {
        // Only one copy of the app may run FROM THE SAME FOLDER (same .cfg / same port).
        // A copy placed in another folder can run at the same time (own .cfg, own DB, own port).
        string folderKey = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(
            System.Text.Encoding.UTF8.GetBytes(AppContext.BaseDirectory.ToLowerInvariant())))[..16];
        using var mutex = new Mutex(true, "M2M_Receiver_1_SingleInstance_" + folderKey, out bool isFirst);
        if (!isFirst)
        {
            MessageBox.Show("You can't open this APP because it has already been open !!!\r\n\r\n"
                + "(To run more Receivers on this PC, copy the exe into another folder and set a different Port there.)", "Tip",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}
