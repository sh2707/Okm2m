using System.Text;

namespace M2M.Shared;

/// <summary>
/// Reads / writes the "Key = Value" .cfg files used by the M2M apps.
/// Works with the old files (entries separated by a single CR) and keeps
/// any keys it does not know about, so nothing in the file is lost on save.
/// </summary>
public sealed class IniConfig
{
    private readonly List<KeyValuePair<string, string>> items = new();
    private string newline = "\r\n";

    public string FilePath { get; }

    public IniConfig(string path)
    {
        FilePath = path;
        Load();
    }

    private void Load()
    {
        items.Clear();
        if (!File.Exists(FilePath)) return;

        string text = File.ReadAllText(FilePath);
        newline = text.Contains('\n') ? "\r\n" : "\r";

        foreach (string raw in text.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries))
        {
            int eq = raw.IndexOf('=');
            if (eq <= 0) continue;
            items.Add(new KeyValuePair<string, string>(raw.Substring(0, eq).Trim(), raw.Substring(eq + 1).Trim()));
        }
    }

    public bool Has(string key)
    {
        foreach (var i in items)
            if (i.Key.Equals(key, StringComparison.OrdinalIgnoreCase)) return true;
        return false;
    }

    public string Get(string key, string def = "")
    {
        foreach (var i in items)
            if (i.Key.Equals(key, StringComparison.OrdinalIgnoreCase)) return i.Value;
        return def;
    }

    public int GetInt(string key, int def) => int.TryParse(Get(key), out int v) ? v : def;

    public bool GetBool(string key, bool def)
    {
        string s = Get(key);
        if (s.Length == 0) return def;
        return s.Equals("true", StringComparison.OrdinalIgnoreCase) || s == "1" || s.Equals("yes", StringComparison.OrdinalIgnoreCase);
    }

    public void Set(string key, string value)
    {
        for (int i = 0; i < items.Count; i++)
        {
            if (items[i].Key.Equals(key, StringComparison.OrdinalIgnoreCase))
            {
                items[i] = new KeyValuePair<string, string>(items[i].Key, value);
                return;
            }
        }
        items.Add(new KeyValuePair<string, string>(key, value));
    }

    public void Set(string key, int value) => Set(key, value.ToString());
    public void Set(string key, bool value) => Set(key, value ? "true" : "false");

    public void Save()
    {
        string? dir = Path.GetDirectoryName(FilePath);
        if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);

        var sb = new StringBuilder();
        foreach (var i in items)
            sb.Append(i.Key).Append(" = ").Append(i.Value).Append(newline);
        File.WriteAllText(FilePath, sb.ToString(), new UTF8Encoding(false));
    }
}
